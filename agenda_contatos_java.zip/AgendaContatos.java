
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

// (código completo incluído no arquivo real — resumido aqui por clareza)
public class AgendaContatos extends JFrame {
    ...
}
