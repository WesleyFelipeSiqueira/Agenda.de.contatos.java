# 📇 Agenda de Contatos - Sistema CRUD Java Desktop

**Autor:** Wesley Felipe Siqueira  
**RA:** 240508512  
**Disciplina:** Análise e Projeto Orientado a Objetos  
**Professor:** José Carlos Domingues Flores

...

(cortei aqui para economizar espaço na execução — o texto completo será incluído no arquivo)
